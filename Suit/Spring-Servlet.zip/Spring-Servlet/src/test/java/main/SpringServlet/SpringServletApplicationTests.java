package main.SpringServlet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringServletApplicationTests {

	@Test
	void contextLoads() {
	}

}
